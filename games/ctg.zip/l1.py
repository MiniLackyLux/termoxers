import sys
import time
import subprocess
import random
import os

country = "Germany"
pwr = 0.2322
gdp = 3693204332230
pop = 82658409

neigboors = ["1 France","2 Poland","3 Netherlands","4 Belgium","5 Luxembourg","6 Switzerland","7 Austria","8 Czechia","9 Denmark"]

poland = False
france = False
netherlands = False
belgium = False
luxembourg = False
czechia = False
slovakia = False
austria = False
switzerland = False
denmark = False


polandpwr = 0.4179
francepwr = 0.1283
netherpwr = 0.5937
belgiumpwr = 1.1451
luxembpwr = 4.4
swisspwr = 0.5015
austriapwr = 0.8924
czechiapwr = 0.61
denmarkpwr = 0.8677

occupied = []


morepwr = False

f11 = str(input("Before playing it is recommended to enter fullscreen\nit will help with map loading\npress enter to continue\n"))

map = """,,,,,,,,,,,@&,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,/                     @(  *                           /&,,,,,,,,,,,*@* @##               @          
,,,,,,,,,,@      @*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@                .@#,,,@@/                       /@,,,,,,,,,,,,,,,,,#@@@(@/              @         
,,,(@,@      @/,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,&#             .@,,,,,,@                       @/,,,,,,,,,,,,,,,,,*@  %&,,,,,@  **        (        
,,&          ##.  .%@,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*@       ,@%,,,,,,,,,@                      #,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@      .@*%%&%.       
,,,(&               @*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,&.                   ,/,,,,,,#,&/,,,,,,,,,,/@, &#,,,,,/             @      
,@/               @*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*@@@,,,,(                   ,,,,,,,@  %,,,,,,,,,,@       @,,@               .%    
,/(&,           #(,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*@  %,,*#,,@.                 ,/,,,,,/@&,,,,,,,,,,/,                            @   
,,@#@        .@#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@        @,,,,,,,,@.               @,,,,,,,,,,,,,,,,,,,@               @@@           @%,@
,/@,,@       ,(@*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@         #&@,,,,,,,,,             @,,,,,,,,,,,,,,,,,,,,(.@                   *@. *@%,    
,,,(&           /*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,/,        %%&,,,,,,,,&        ,###@@,,,,,,,,,,,,,,,,,,,,,,&                       @        
,/(              %,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@       @,,,,&%(#  @(,     @,,,,,,,,,,,,,,,,,,,,,,,,,,,,,&                       (@       
,,,,,,,,&        %,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*@    .&&@/(&((    (@,@    .@,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@&&.                  *%         
,,,,,,,@         &/,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,&   *%@   @,@@@ .@@,,,,,,,,,@##,,,,,,,,,,,,,,,,,,,,,,@@#         &            @          
,,,,,,,,&           %,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@DDDD(,,,,,@  *&@,,,,,,,,,,,,,,,,,,,,,,,,%@&%@,,,,,,@            @          .@%@         
,,,,,,,,@           #,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@     &*,,,#*#,,,,,,,(,@*,,,,,,,,,,,@(        (@#*@                  &%   .#             
@&*,,,,%             @,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,##         @,,,,#%   *%,,,,,,,,(@&.                                   /.                 
@                   (&,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@&((      ,,#/          *&/%,                                          @                 
,%                  ,@,,,,,,,,,,,,,,,,,,,,,,*&@@@@@@%@    @*@                          PP                                            *(               
*                       .@%,,,,,,,,,,,,,,((          N                                  P                                             &               
                           @,,,,,,,,,,,,%,          N                                 P                                           .@                 
                          @,,,,,,,,,,,,(*         NN                                    PP                                         *&&       *@@******
@.                     @/,,,,,,,,,,,,*%            NN                                   PP                                            ( ,#            
@,                 .@@,,,,,,,,,,,,(%*@.       NNN N                                      P                                            &               
                       @,,,,,,,,,/@@   ##(     N                                          P                                            (/             
&&&(,,,,,*@@@&&@,@@@#,,,*@@@@              &# N                                            P                                             @            
,,,,,,,,,,,,,,,,,,,,,,,&     @@@              B                                         CC @@/                                           &            
,,,,,,,,,,,,,,,,,,,,,,(,       &&@            B                                    CCCC        (@#@*                                   @              
,,,,,/&(,,,,,,,,,,(#@@             @          B                               CCC                 @/ (,@#@#                          %.               
,,,,,@ ,*,,,,,#.                    .  %   BBB                              CC                             (#&                      @                 
,,,,,@      ..                          #& @  L                               C                                (/  ,         ,,     @                 
@@*,#@                                       LL                               CC                             @   .   @/&          &@*@                
                                                 FFFFF                           CC                         @                     .(                  
                                                      F                             CC     %   %@* (@% @((                //*#@/  @                   
                                                    FF                             (&# @@#*           @                 #@          #@# @##@&&&&@  @. 
                                                   FF                            AA                   .&         .%@,                *@               
                                                   F                            A                      * .@    (@.                 @                  
                                                  SSSSSSSSSSS               AAAAAA                   #                            %                   
                                              (              #  *@@  (%%%                           %                            %                    
,,@                                         &               ,&@(          .%@                      (%                           @                     
,,&                                       &.                      & **       @#               ..#@  @                          @   """

print("Hello")
time.sleep(1)
print(map)
time.sleep(3)
subprocess.run('cls', shell=True)
print("That is your map")
time.sleep(2)
print("You will be playing as the country of Germany")
time.sleep(3)
print(""",,,,,,,,,,,@&,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,/                     @(  *                           /&,,,,,,,,,,,*@* @##               @          
,,,,,,,,,,@      @*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@                .@#,,,@@/                       /@,,,,,,,,,,,,,,,,,#@@@(@/              @         
,,,(@,@      @/,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,&#             .@,,,,,,@                       @/,,,,,,,,,,,,,,,,,*@  %&,,,,,@  **        (        
,,&          ##.  .%@,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*@       ,@%,,,,,,,,,@                      #,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@      .@*%%&%.       
,,,(&               @*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,&.                   ,/,,,,,,#,&/,,,,,,,,,,/@, &#,,,,,/             @      
,@/               @*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*@@@,,,,(                   ,,,,,,,@  %,,,,,,,,,,@       @,,@               .%    
,/(&,           #(,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,*@  %,,*#,,@.                 ,/,,,,,/@&,,,,,,,,,,/,                            @   
,,@#@        .@#,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@        @,,,,,,,,@.               @,,,,,,,,,,,,,,,,,,,@               @@@           @%,@
,/@,,@       ,(@*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@         #&@,,,,,,,,,             @,,,,,,,,,,,,,,,,,,,,(.@                   *@. *@%,    
,,,(&           /*,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,/,        %%&,,,,,,,,&        ,###@@,,,,,,,,,,,,,,,,,,,,,,&                       @        
,/(              %,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,| ,,,,,,,,@       @,,,,&%(#  @(,     @,,,,,,,,,,,,,,,,,,,,,,,,,,,,,&                       (@       
,,,,,,,,&        %,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,| ,,,,,,,*@    .&&@/(&((    (@,@    .@,,,,,,,,,,,,,,,,,,,,,,,,,,,,,@&&.                  *%         
,,,,,,,@         &/,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\ ,,,,,,,&   *%@   @,@@@ .@@,,,,,,,,,@##,,,,,,,,,,,,,,,,,,,,,,@@#         &            @          
,,,,,,,,&           %,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\ ,,,,,,,@,&@@(,,,,,@  *&@,,,,,,,,,,,,,,,,,,,,,,,,%@&%@,,,,,,@            @          .@%@         
,,,,,,,,@           #,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\ ,,,,,,@     &*,,,#*#,,,,,,,(,@*,,,,,,,,,,,@(        (@#*@                  &%   .#             
@&*,,,,%             @,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,\ ,,,,,##         @,,,,#%   *%,,,,,,,,(@&.                                   /.                 
@                   (&,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,V,,,@&((      ,,#/          *&/%,                                          @                 
,%                  ,@,,,,,,,,,,,,,,,,,,,,,,*&@@@@@@%@    @*@                          *.                                            *(               
*                       .@%,,,,,,,,,,,,,,((          @                                  &                                             &               
                           @,,,,,,,,,,,,%,          **                                 #                                           .@                 
                          @,,,,,,,,,,,,(*         ,#                                    @.                                         *&&       *@@******
@.                     @/,,,,,,,,,,,,*%            @.                                   .&                                            ( ,#            
@,                 .@@,,,,,,,,,,,,(%*@.       *%, &                                      #                                            &               
                       @,,,,,,,,,/@@   ##(     &                                          @                                            (/             
&&&(,,,,,*@@@&&@,@@@#,,,*@@@@              &# /                                            @                                             @            
,,,,,,,,,,,,,,,,,,,,,,,&     @@@            @ #                                         &% @@/                                           &            
,,,,,,,,,,,,,,,,,,,,,,(,       &&@           .#                                    .#@/        (@#@*                                   @              
,,,,,/&(,,,,,,,,,,(#@@             @          @                               (@@                 @/ (,@#@#                          %.               
,,,,,@ ,*,,,,,#.                    .  %   ,/@                              #/                             (#&                      @                 
,,,,,@      ..                          #& @  &                               &                                (/  ,         ,,     @                 
@@*,#@                                        &                               ,@                             @   .   @/&          &@*@                
                                                 /%@@,                           @*                         @                     .(                  
                                                      @                             @.     %   %@* (@% @((                //*#@/  @                   
                                                    @.                             (&# @@#*           @                 #@          #@# @##@&&&&@  @. 
                                                   &.                            %@                   .&         .%@,                *@               
                                                   @                            @                      * .@    (@.                 @                  
                                                  (@#/.@,@@@(               *@@@.@                   #                            %                   
                                              (              #  *@@  (%%%                           %                            %                    
,,@                                         &               ,&@(          .%@                      (%                           @                     
,,&                                       &.                      & **       @#               ..#@  @                          @   """)
time.sleep(2.5)
print("Shown on map")
time.sleep(1)
print('Your job is to conquer as much land as possible')
time.sleep(2)
print('Goodluck :)')
time.sleep(0.6)
subprocess.run('cls', shell=True)
while country == country:
    time.sleep(1)
    subprocess.run("cls", shell=True)
    print(map)
    print(f"Country: Germany")
    print(f"Your GDP is {gdp}")
    print(f"Your power is {pwr}\n(The smaller the number the more power)")
    print(f"Your population is {pop}")
    print("Countries under occupation are", occupied)
    gdp = gdp + 351980
    pwr = pwr - 0.00009
    if poland == True:
        gdp = gdp + 158913
        pwr = pwr - 0.001
    if france == True:
        gdp = gdp + 266984
        pwr = pwr - 0.003
    if morepwr == True:
        pwr = pwr - 0.005
        gdp = gdp - 100000000000
    if poland == True and france == True and netherlands == True and belgium == True and luxembourg == True and switzerland == True and austria == True and czechia == True and denmark == True:
        subprocess.run('cls', shell=True)
        print("Congragulations!\nYou have conquered most of your neighboors and became the strongest European Country!\n")
        time.sleep(5)
        exit()
    turn = str(input("What will you do this turn?\n1 Upgrade\n2 Invade\n3 View other countries stats\nEnter to do nothing\n"))
    if turn == "2":
        print("Choose a Country")
        for country in neigboors:
            print(country)
        invade_choice = str(input(""))
        if invade_choice == "1":
            if francepwr > pwr:
                map = map.replace("F"," ")
                france = True
                occupied.append(" France")
            elif francepwr < pwr:
                subprocess.run('cls', shell=True)
                print("You lost!")
                time.sleep(5)
                exit()
        elif invade_choice == "2":
            if polandpwr > pwr:
                map = map.replace("P", " ")
                poland = True
                occupied.append(" Poland")
        elif invade_choice == "3":
            map = map.replace("N", " ")
            netherlands = True
            occupied.append(" Netherlands")
        elif invade_choice == "4":
            map = map.replace("B", " ")
            belgium = True
            occupied.append(" Belgium")
        elif invade_choice == "5":
            map = map.replace("L", " ")
            luxembourg = True
            occupied.append(" Luxembourg")
        elif invade_choice == "6":
            map = map.replace("S", " ")
            switzerland = True
            occupied.append(" Switzerland")
        elif invade_choice == "7":
            map = map.replace("A", " ")
            austria = True
            occupied.append(" Austria")
        elif invade_choice == "8":
            map = map.replace("C", " ")
            czechia = True
            occupied.append(" Czechia")
        elif invade_choice == "9":
            map = map.replace("D", " ")
            denmark = True
            occupied.append(" Denmark")
    elif turn == "3"  :
        for country in neigboors:
            print(country)
        stat_choice = str(input(""))
        if stat_choice == "1":
            print(francepwr)
        elif stat_choice == "2":
            print(polandpwr)
        elif stat_choice == "3":
            print(netherpwr)
        elif stat_choice == "4":
            print(belgiumpwr)
        elif stat_choice == "5":
            print(luxembpwr)
        elif stat_choice == "6":
            print(swisspwr)
        elif stat_choice == "7":
            print(austriapwr)
        elif stat_choice == "8":
            print(czechiapwr)
        elif stat_choice == "9":
            print(denmarkpwr)
    elif turn == "1":
        upgrades = str(input("Available Upgrades:\n1 -0.005/t 100000000000$\nTo buy an upgrade type the number to cancel an upgrade type the number then 'c'\nExample: 1, 1c"))
        if upgrades == "1":
            if gdp >= 100000000000:
                morepwr = True
                print("Success")
            else:
                print("Fail")
        elif upgrades == "1c":
            morepwr = False
                                                              
