import random

while True:
    options = ("rock", "paper", "scissors")
    player = input("Enter:\nRock\nPaper\nScissors\n").lower()
    computer = random.choice(options)

    if player not in options:
        print("Enter a valid Option")
    else:
        if player == computer:
            print("Tie!")
        elif player == "paper" and computer == "rock":
            print("You win")
        elif player == "paper" and computer == "scissors":
            print("You lose")
        elif player == "scissors" and computer == "rock":
            print("You lose")
        elif player == "scissors" and computer == "paper":
            print("You win")
        elif player == "rock" and computer == "paper":
            print("You lose")
        elif player == "rock" and computer == "scissors":
            print("You win")
        else:
            print("Error")
    play_again = input("Do you want to play again?(y,n)\n")
    if play_again != "y":
        print("Bye")
        break
    else:
        pass
    